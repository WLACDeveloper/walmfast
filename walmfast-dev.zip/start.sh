pip install customtkinter pygame Pillow show-in-file-manager crossfiledialog
python main.py
