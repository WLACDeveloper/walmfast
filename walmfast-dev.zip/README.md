# WALMFast

WALMFAST - WALM Fastboot - making it easier to flash devices via fastboot

