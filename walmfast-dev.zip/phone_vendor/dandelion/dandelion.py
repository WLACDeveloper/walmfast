model = '          Redmi 9A'
