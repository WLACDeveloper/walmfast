model = '         Redmi A1+'
